# Bank-Management-System
A Bank Management System using PHP, MySQL, HTML, CSS and Bootstrap. It was done as a part of Database Course.
# Features
* A few basic security Aspects - SQL Injection, Password Hash and stuff
* All forms validated on Server Side using PHP
* Nice Looking WebPages
# Running the project
* Install XAMPP
* Configure the port number in dbconnect.php file
* Import sample data into database via phpmyadmin using the bank.sql file
* Run XAMPP and open the web page using browser - 127.0.0.1/bank/code



